# coding:utf-8
import re

class RequestParserClass(object):

    def __init__(self, f):
        self.flow = f
        self.requestDict = {}
        self.request_id = None
        self.request_url = None
        self.request_method = None
        self.request_post_data = None
    def parser(self):
        getheaders = re.findall(r'(.*?)\:.(.*?)\r\n', str(self.flow.request.headers), re.S)
        for k, v in getheaders:
            self.requestDict[k] = v

        self.request_id = self.flow.id
        self.request_url = self.flow.request.url
        self.request_method = self.flow.request.method
        self.request_post_data = self.flow.request.raw_content